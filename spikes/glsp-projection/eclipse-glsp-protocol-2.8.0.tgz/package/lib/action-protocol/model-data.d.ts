/********************************************************************************
 * Copyright (c) 2021-2023 STMicroelectronics and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import * as sprotty from 'sprotty-protocol/lib/actions';
import { GModelRootSchema } from '../model/model-schema';
import { Action, RequestAction, ResponseAction } from './base-protocol';
import { Args } from './types';
/**
 * Sent from the server to the client in order to set the model. If a model is already present, it is replaced.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `RequestModelActions`.
 */
export interface RequestModelAction extends RequestAction<SetModelAction>, sprotty.RequestModelAction {
    kind: typeof RequestModelAction.KIND;
    /**
     * Additional options used to compute the graphical model.
     */
    options?: Args;
}
export declare namespace RequestModelAction {
    const KIND = "requestModel";
    function is(object: unknown): object is RequestModelAction;
    function create(options?: {
        options?: Args;
        requestId?: string;
    }): RequestModelAction;
}
/**
 * Sent from the server to the client in order to set the model. If a model is already present, it is replaced.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `SetModelActions`.
 */
export interface SetModelAction extends ResponseAction, sprotty.SetModelAction {
    kind: typeof SetModelAction.KIND;
    /**
     * The new graphical model root.
     */
    newRoot: GModelRootSchema;
}
export declare namespace SetModelAction {
    const KIND = "setModel";
    function is(object: unknown): object is SetModelAction;
    function create(newRoot: GModelRootSchema, options?: {
        responseId?: string;
    }): SetModelAction;
}
/**
 * Sent from the server to the client in order to update the model. If no model is present yet, this behaves the same as
 * a {@link SetModelAction}. The transition from the old model to the new one can be animated.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `UpdateModelActions`.
 */
export interface UpdateModelAction extends Action, Omit<sprotty.UpdateModelAction, 'matches' | 'cause'> {
    kind: typeof UpdateModelAction.KIND;
    newRoot: GModelRootSchema;
    /**
     * Boolean flag to indicate wether updated/changed elements should be animated in the diagram.
     */
    animate?: boolean;
}
export declare namespace UpdateModelAction {
    const KIND = "updateModel";
    function is(action: unknown): action is UpdateModelAction;
    function create(newRoot: GModelRootSchema, options?: {
        animate?: boolean;
    }): UpdateModelAction;
}
/**
 * Sent from the server to the client in order to indicate that the source model has changed.
 * The source model denotes the data source from which the diagram has been originally derived (such as a file, a database, etc.).
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `SourceModelChangedActions`.
 */
export interface SourceModelChangedAction extends Action {
    kind: typeof SourceModelChangedAction.KIND;
    /**
     * A human readable name of the source model (e.g. the file name).
     */
    sourceModelName: string;
}
export declare namespace SourceModelChangedAction {
    const KIND = "sourceModelChanged";
    function is(object: unknown): object is SourceModelChangedAction;
    function create(sourceModelName: string): SourceModelChangedAction;
}
//# sourceMappingURL=model-data.d.ts.map