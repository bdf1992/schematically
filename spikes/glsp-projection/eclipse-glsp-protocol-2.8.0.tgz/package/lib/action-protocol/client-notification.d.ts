import { Action } from './base-protocol';
/**
 * Sent by the server (or the client) to signal a status change.
 * If a timeout is given the respective status should disappear after the timeout is reached.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `StatusAction`s.
 */
export interface StatusAction extends Action {
    kind: typeof StatusAction.KIND;
    /**
     * The severity of the status.
     */
    severity: SeverityLevel;
    /**
     * The user-facing message describing the status.
     */
    message: string;
    /**
     * Timeout after which a displayed status should disappear.
     */
    timeout?: number;
}
export declare namespace StatusAction {
    const KIND = "status";
    function is(object: unknown): object is StatusAction;
    function create(message: string, options?: {
        severity?: SeverityLevel;
        timeout?: number;
    }): StatusAction;
}
/**
 * The possible server status severity levels.
 */
export type SeverityLevel = 'NONE' | 'INFO' | 'WARNING' | 'ERROR' | 'FATAL' | 'OK';
/**
 * Sent by the server (or the client) to notify the user about something of interest. Typically this message is handled by
 * the client by showing a message to the user with the application's message service.
 * If a timeout is given the respective message should disappear after the timeout is reached.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `MessageAction`s.
 */
export interface MessageAction extends Action {
    kind: typeof MessageAction.KIND;
    severity: SeverityLevel;
    /**
     * The message that shall be shown to the user.
     */
    message: string;
    /**
     * Further details on the message.
     */
    details?: string;
}
export declare namespace MessageAction {
    const KIND = "message";
    function is(object: unknown): object is MessageAction;
    function create(message: string, options?: {
        severity?: SeverityLevel;
        details?: string;
    }): MessageAction;
}
/**
 * Sent to request presenting the progress of a long running process in the UI.
 */
export interface StartProgressAction extends Action {
    kind: typeof StartProgressAction.KIND;
    /**
     * An ID that can be used in subsequent `updateProgress` and `endProgress` events to make them refer to the same progress reporting.
     */
    progressId: string;
    /**
     * Short title of the progress reporting. Shown in the UI to describe the long running process.
     */
    title: string;
    /**
     * Optional additional progress message. Shown in the UI to describe the long running process.
     */
    message?: string;
    /**
     * Progress percentage to display (value range: 0 to 100). If omitted no percentage is shown.
     */
    percentage?: number;
}
export declare namespace StartProgressAction {
    const KIND = "startProgress";
    function is(object: unknown): object is StartProgressAction;
    function create(options: {
        progressId: string;
        title: string;
        message?: string;
        percentage?: number;
    }): StartProgressAction;
}
/**
 * Sent to presenting an update of the progress of a long running process in the UI.
 */
export interface UpdateProgressAction extends Action {
    kind: typeof UpdateProgressAction.KIND;
    /**
     * The ID of the progress reporting to update.
     */
    progressId: string;
    /**
     * The message to show in the progress reporting.
     */
    message?: string;
    /**
     * The percentage (value range: 0 to 100) to show in the progress reporting.
     */
    percentage?: number;
}
export declare namespace UpdateProgressAction {
    const KIND = "updateProgress";
    function is(object: unknown): object is UpdateProgressAction;
    function create(progressId: string, options?: {
        message?: string;
        percentage?: number;
    }): UpdateProgressAction;
}
/**
 * Sent to end the reporting of a progress.
 */
export interface EndProgressAction extends Action {
    kind: typeof EndProgressAction.KIND;
    /**
     * The ID of the progress reporting to update.
     */
    progressId: string;
    /**
     * The message to show in the progress reporting.
     */
    message?: string;
}
export declare namespace EndProgressAction {
    const KIND = "endProgress";
    function is(object: unknown): object is EndProgressAction;
    function create(progressId: string, message?: string): EndProgressAction;
}
//# sourceMappingURL=client-notification.d.ts.map