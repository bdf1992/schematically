/********************************************************************************
 * Copyright (c) 2021-2023 STMicroelectronics and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { Point } from 'sprotty-protocol';
import * as sprotty from 'sprotty-protocol/lib/actions';
import { Operation } from './base-protocol';
import { Args } from './types';
/**
 * Common interface for all create {@link Operation}s in GLSP.
 * The corresponding namespace offers a helper function for type guard checks.
 */
export interface CreateOperation extends Operation {
    /**
     * The type of the element that should be created.
     */
    elementTypeId: string;
}
export declare namespace CreateOperation {
    function is(object: unknown): object is CreateOperation;
    /**
     * Typeguard function to check wether the given object is a {@link CreateOperation} with the given `kind`.
     * @param object The object to check.
     * @param kind  The expected operation kind.
     * @returns A type literal indicating wether the given object is a create operation with the given kind.
     */
    function hasKind(object: unknown, kind: string): object is CreateOperation;
}
/**
 * In order to create a node in the model the client can send a CreateNodeOperation with the necessary information to create
 * the element that corresponds to that node in the source model.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `CreateNodeOperations`.
 */
export interface CreateNodeOperation extends CreateOperation {
    kind: typeof CreateNodeOperation.KIND;
    location?: Point;
    containerId?: string;
}
export declare namespace CreateNodeOperation {
    const KIND = "createNode";
    function is(object: unknown): object is CreateNodeOperation;
    function create(elementTypeId: string, options?: {
        location?: Point;
        containerId?: string;
        args?: Args;
    }): CreateNodeOperation;
}
/**
 * In order to create an edge in the model the client can send a `CreateEdgeOperation` with the necessary information to create
 * the element that corresponds to that edge in the source model.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `CreateEdgeOperations`.
 */
export interface CreateEdgeOperation extends CreateOperation {
    kind: typeof CreateEdgeOperation.KIND;
    sourceElementId: string;
    targetElementId: string;
}
export declare namespace CreateEdgeOperation {
    const KIND = "createEdge";
    function is(object: unknown): object is CreateEdgeOperation;
    function create(options: {
        elementTypeId: string;
        sourceElementId: string;
        targetElementId: string;
        args?: Args;
    }): CreateEdgeOperation;
}
/**
 * The client sends a `DeleteElementOperation` to the server to request the deletion of an element from the source model.
 * The corresponding namespace declares the action kind as constant and offers helper functions for type guard checks
 * and creating new `DeleteElementOperations`.
 */
export interface DeleteElementOperation extends Operation, Omit<sprotty.DeleteElementAction, 'kind'> {
    kind: typeof DeleteElementOperation.KIND;
    /**
     * The ids of the elements to be deleted.
     */
    elementIds: string[];
}
export declare namespace DeleteElementOperation {
    const KIND = "deleteElement";
    function is(object: unknown): object is DeleteElementOperation;
    function create(elementIds: string[], options?: {
        args?: Args;
    }): DeleteElementOperation;
}
//# sourceMappingURL=element-creation.d.ts.map