/********************************************************************************
 * Copyright (c) 2023-2026 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { Deferred } from 'sprotty-protocol';
import { Disposable } from 'vscode-jsonrpc';
import { Action, ActionMessage } from '../action-protocol/base-protocol';
import { Emitter, Event } from '../utils/event';
import { ActionMessageHandler, ClientState, GLSPClient } from './glsp-client';
import { GLSPClientProxy, GLSPServer } from './glsp-server';
import { DisposeClientSessionParameters, InitializeClientSessionParameters, InitializeParameters, InitializeResult } from './types';
export declare const GLOBAL_HANDLER_ID = "*";
/**
 * A simple {@link GLSPClient} implementation for use cases where the client & server are running
 * in the same context/process without a communication layer (like json-rpc) between. The client
 * directly communicates with a given {@link GLSPServer} instance.
 */
export declare class BaseGLSPClient implements GLSPClient {
    protected options: GLSPClient.Options;
    protected serverDeferred: Deferred<GLSPServer>;
    protected onStartDeferred: Deferred<void>;
    protected onStopDeferred: Deferred<void>;
    readonly proxy: GLSPClientProxy;
    protected startupTimeout: number;
    protected actionMessageHandlers: Map<string, ActionMessageHandler[]>;
    protected pendingServerInitialize?: Promise<InitializeResult>;
    protected onServerInitializedEmitter: Emitter<InitializeResult>;
    get onServerInitialized(): Event<InitializeResult>;
    protected onCurrentStateChangedEmitter: Emitter<ClientState>;
    get onCurrentStateChanged(): Event<ClientState>;
    protected _state: ClientState;
    protected set state(state: ClientState);
    protected get state(): ClientState;
    protected _server?: GLSPServer;
    protected get checkedServer(): GLSPServer;
    protected _initializeResult?: InitializeResult;
    get initializeResult(): InitializeResult | undefined;
    constructor(options: GLSPClient.Options);
    protected createProxy(): GLSPClientProxy;
    configureServer(server: GLSPServer): void;
    start(): Promise<void>;
    initializeServer(params: InitializeParameters): Promise<InitializeResult>;
    initializeClientSession(params: InitializeClientSessionParameters): Promise<void>;
    disposeClientSession(params: DisposeClientSessionParameters): Promise<void>;
    shutdownServer(): Promise<void>;
    stop(): Promise<void>;
    sendActionMessage(message: ActionMessage<Action>): void;
    onActionMessage(handler: ActionMessageHandler, clientId?: string): Disposable;
    get currentState(): ClientState;
    onStart(): Promise<void>;
    onStop(): Promise<void>;
    get id(): string;
    protected checkState(): void | never;
    setStartupTimeout(ms: number): void;
}
//# sourceMappingURL=base-glsp-client.d.ts.map