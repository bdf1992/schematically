/********************************************************************************
 * Copyright (c) 2023 STMicroelectronics and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { AbstractMessageReader, AbstractMessageWriter, DataCallback, Disposable, Logger, Message, MessageConnection } from 'vscode-jsonrpc';
/**
 * A wrapper interface that enables the reuse of the {@link WebSocketMessageReader} and {@link WebSocketMessageWriter}
 * independent of the underlying WebSocket implementation/library. e.g. one could use Socket.io instead of plain WebSockets
 */
export interface WebSocketWrapper extends Disposable {
    send(content: string | ArrayBufferLike | ArrayBufferView): void;
    onMessage(cb: (data: unknown) => void): void;
    onError(cb: (reason: unknown) => void): void;
    onClose(cb: (code: number, reason: string) => void): void;
}
/**
 * Creates a {@link WebSocketWrapper} for the given plain WebSocket
 * @param socket The socket to wrap
 */
export declare function wrap(socket: WebSocket): WebSocketWrapper;
/**
 * A `vscode-jsonrpc` {@link MessageReader} that reads messages from an underlying {@link WebSocketWrapper}.
 */
export declare class WebSocketMessageReader extends AbstractMessageReader {
    protected readonly socket: WebSocketWrapper;
    protected state: 'initial' | 'listening' | 'closed';
    protected callback?: DataCallback;
    protected eventQueue: Array<{
        message?: unknown;
        error?: unknown;
    }>;
    constructor(socket: WebSocketWrapper);
    listen(callback: DataCallback): Disposable;
    protected handleMessage(message: any): void;
    protected fireError(error: unknown): void;
    protected fireClose(): void;
}
/**
 * A `vscode-jsonrpc` {@link MessageReader} that writes messages to an underlying {@link WebSocketWrapper}.
 */
export declare class WebSocketMessageWriter extends AbstractMessageWriter {
    protected readonly socket: WebSocketWrapper;
    protected errorCount: number;
    constructor(socket: WebSocketWrapper);
    end(): void;
    write(msg: Message): Promise<void>;
}
/**
 * Create a `vscode-jsonrpc` {@link MessageConnection} on top of a given {@link WebSocketWrapper}.
 */
export declare function createWebSocketConnection(socket: WebSocketWrapper, logger?: Logger): MessageConnection;
/**
 * Creates a new {@link MessageConnection} on top of the given websocket on open.
 * @param webSocket The target webSocket
 * @param onConnection Optional callback that is invoked after the connection has been created
 * @param logger Optional connection logger
 * @returns A promise of the created connection
 */
export declare function listen(webSocket: WebSocket, onConnection?: (connection: MessageConnection) => void, logger?: Logger): Promise<MessageConnection>;
//# sourceMappingURL=websocket-connection.d.ts.map