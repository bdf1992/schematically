/********************************************************************************
 * Copyright (c) 2023-2026 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { Logger, MessageConnection } from 'vscode-jsonrpc';
import { MaybePromise } from '../../utils/type-util';
export interface GLSPWebSocketOptions {
    /**
     * Allow automatic reconnect of WebSocket connections
     * @default true
     */
    reconnecting?: boolean;
    /**
     * Max attempts of reconnects
     * @default Infinity
     */
    reconnectAttempts?: number;
    /**
     * The time delay in milliseconds between reconnect attempts
     * @default 1000
     */
    reconnectDelay?: number;
}
export declare const GLSPConnectionHandler: unique symbol;
export interface GLSPConnectionHandler {
    onConnection?(connection: MessageConnection): MaybePromise<void>;
    onReconnect?(connection: MessageConnection): MaybePromise<void>;
    logger?: Logger;
}
export declare class GLSPWebSocketProvider {
    protected url: string;
    protected webSocket: WebSocket;
    protected reconnectTimer?: NodeJS.Timeout;
    protected reconnectAttempts: number;
    /** Whether a connection was ever successfully established; controls `onConnection` vs `onReconnect`. */
    protected hasConnected: boolean;
    protected options: GLSPWebSocketOptions;
    constructor(url: string, options?: GLSPWebSocketOptions);
    protected createWebSocket(url: string): WebSocket;
    listen(handler: GLSPConnectionHandler, isReconnecting?: boolean): Promise<MessageConnection>;
    protected scheduleReconnect(handler: GLSPConnectionHandler): void;
    protected clearReconnect(): void;
}
//# sourceMappingURL=ws-connection-provider.d.ts.map