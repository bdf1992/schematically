import { Disposable, Message, MessageConnection } from 'vscode-jsonrpc';
import { ActionMessage } from '../../action-protocol/base-protocol';
import { Emitter, Event } from '../../utils/event';
import { ActionMessageHandler, ClientState, GLSPClient } from '../glsp-client';
import { GLSPClientProxy } from '../glsp-server';
import { DisposeClientSessionParameters, InitializeClientSessionParameters, InitializeParameters, InitializeResult } from '../types';
import { ConnectionProvider, JsonrpcGLSPClient } from './glsp-jsonrpc-client';
export declare class BaseJsonrpcGLSPClient implements GLSPClient {
    readonly id: string;
    protected readonly connectionProvider: ConnectionProvider;
    protected connectionPromise?: Promise<MessageConnection>;
    protected resolvedConnection?: MessageConnection;
    protected onStop?: Promise<void>;
    protected pendingServerInitialize?: Promise<InitializeResult>;
    protected onServerInitializedEmitter: Emitter<InitializeResult>;
    get onServerInitialized(): Event<InitializeResult>;
    protected onActionMessageNotificationEmitter: Emitter<ActionMessage<import("../../action-protocol/base-protocol").Action>>;
    protected get onActionMessageNotification(): Event<ActionMessage>;
    protected onCurrentStateChangedEmitter: Emitter<ClientState>;
    get onCurrentStateChanged(): Event<ClientState>;
    protected _state: ClientState;
    protected set state(state: ClientState);
    protected get state(): ClientState;
    protected _initializeResult?: InitializeResult;
    get initializeResult(): InitializeResult | undefined;
    constructor(options: JsonrpcGLSPClient.Options);
    start(): Promise<void>;
    initializeServer(params: InitializeParameters): Promise<InitializeResult>;
    initializeClientSession(params: InitializeClientSessionParameters): Promise<void>;
    disposeClientSession(params: DisposeClientSessionParameters): Promise<void>;
    onActionMessage(handler: ActionMessageHandler, clientId?: string): Disposable;
    sendActionMessage(message: ActionMessage): void;
    shutdownServer(): Promise<void>;
    stop(): Promise<void>;
    protected get checkedConnection(): MessageConnection;
    protected resolveConnection(): Promise<MessageConnection>;
    protected doCreateConnection(): Promise<MessageConnection>;
    protected handleConnectionError(error: Error, message: Message | undefined, count: number | undefined): void;
    protected handleConnectionClosed(): void;
    isConnectionActive(): boolean;
    get currentState(): ClientState;
}
/**
 * Default {@link GLSPClientProxy} implementation for jsonrpc-based client-server communication with typescript based servers.
 */
export declare class JsonrpcClientProxy implements GLSPClientProxy {
    protected clientConnection?: MessageConnection;
    protected enableLogging: boolean;
    initialize(clientConnection: MessageConnection, enableLogging?: boolean): void;
    process(message: ActionMessage): void;
}
//# sourceMappingURL=base-jsonrpc-glsp-client.d.ts.map