/********************************************************************************
 * Copyright (c) 2020-2026 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { MessageConnection, NotificationType, NotificationType0, RequestType } from 'vscode-jsonrpc';
import { ActionMessage } from '../../action-protocol/base-protocol';
import { MaybePromise } from '../../utils/type-util';
import { GLSPClient } from '../glsp-client';
import { DisposeClientSessionParameters, InitializeClientSessionParameters, InitializeParameters, InitializeResult } from '../types';
export type ConnectionProvider = MessageConnection | (() => MaybePromise<MessageConnection>);
export declare namespace JsonrpcGLSPClient {
    interface Options extends GLSPClient.Options {
        connectionProvider: ConnectionProvider;
    }
    function isOptions(object: unknown): object is Options;
    const ActionMessageNotification: NotificationType<ActionMessage<import("../../action-protocol/base-protocol").Action>>;
    const InitializeRequest: RequestType<InitializeParameters, InitializeResult, void>;
    const InitializeClientSessionRequest: RequestType<InitializeClientSessionParameters, void, void>;
    const DisposeClientSessionRequest: RequestType<DisposeClientSessionParameters, void, void>;
    const ShutdownNotification: NotificationType0;
    const ClientNotReadyMsg = "JsonrpcGLSPClient is not ready yet";
    function error(message: string, ...optionalParams: unknown[]): void;
}
//# sourceMappingURL=glsp-jsonrpc-client.d.ts.map