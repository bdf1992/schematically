/********************************************************************************
 * Copyright (c) 2023 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { BringToFrontAction, CollapseExpandAction, CollapseExpandAllAction, GetSelectionAction, GetViewportAction, HoverFeedbackAction, MoveAction, OpenAction, SelectionResult, SetBoundsAction, SetViewportAction, ViewportResult } from 'sprotty-protocol/lib/actions';
declare module 'sprotty-protocol/lib/actions' {
    namespace BringToFrontAction {
        function is(object: unknown): object is BringToFrontAction;
    }
    namespace CollapseExpandAction {
        function is(object: unknown): object is CollapseExpandAction;
    }
    namespace CollapseExpandAllAction {
        function is(object: unknown): object is CollapseExpandAllAction;
    }
    namespace GetSelectionAction {
        function is(object: unknown): object is GetSelectionAction;
    }
    namespace GetViewportAction {
        function is(object: unknown): object is GetViewportAction;
    }
    namespace HoverFeedbackAction {
        function is(object: unknown): object is HoverFeedbackAction;
    }
    namespace MoveAction {
        function is(object: unknown): object is MoveAction;
    }
    namespace OpenAction {
        function is(object: unknown): object is OpenAction;
    }
    namespace SelectionResult {
        function is(object: unknown): object is SelectionResult;
    }
    namespace SetBoundsAction {
        function is(object: unknown): object is SetBoundsAction;
    }
    namespace SetViewportAction {
        function is(object: unknown): object is SetViewportAction;
    }
    namespace ViewportResult {
        function is(object: unknown): object is ViewportResult;
    }
}
export { BringToFrontAction, CollapseExpandAction, CollapseExpandAllAction, GetSelectionAction, GetViewportAction, HoverFeedbackAction, MoveAction, OpenAction, SelectionResult, SetBoundsAction, SetViewportAction, ViewportResult };
//# sourceMappingURL=sprotty-actions.d.ts.map