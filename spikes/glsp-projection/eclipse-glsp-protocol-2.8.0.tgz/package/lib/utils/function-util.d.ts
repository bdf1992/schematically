/********************************************************************************
 * Copyright (c) 2026 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
/**
 * Minimal lodash-compatible debounce subset.
 * Compared to `lodash.DebouncedFunc<T>`:
 * - The debounced call returns `void` instead of `ReturnType<T> | undefined`.
 * - `flush()`, `pending()`, and `maxWait` are not supported.
 */
export interface DebouncedFunc<T extends (...args: any[]) => any> {
    (...args: Parameters<T>): void;
    cancel(): void;
}
export interface DebounceSettings {
    leading?: boolean;
    trailing?: boolean;
}
/**
 * Minimal lodash-compatible debounce. See {@link DebouncedFunc} for intentional differences from `lodash.debounce`.
 */
export declare function debounce<T extends (...args: any[]) => any>(func: T, wait: number, options?: DebounceSettings): DebouncedFunc<T>;
//# sourceMappingURL=function-util.d.ts.map