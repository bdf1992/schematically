/**
 * Generates a random RFC-4122 v4 UUID.
 *
 * This is the single entry point for UUID creation across all GLSP components: routing every
 * caller through `@eclipse-glsp/protocol` keeps `uuid` an isolated, auditable dependency instead
 * of letting each package pull in (and pin) its own copy.
 *
 * @returns a newly generated v4 UUID
 */
export declare function generateUuid(): string;
/**
 * Checks whether the given string is a well-formed RFC-4122 UUID.
 *
 * @param value the string to test
 * @returns `true` if {@link value} is a valid UUID
 */
export declare function isUuid(value: string): boolean;
//# sourceMappingURL=uuid.d.ts.map