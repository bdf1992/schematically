/********************************************************************************
 * Copyright (c) 2024 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { Direction } from './geometry-util';
/**
 * A vector in two-dimensional space with an x and y component. A vector describes a direction and magnitued
 * epresented by coordinates that describe its endpoint relative to a starting point.
 */
export interface Vector {
    x: number;
    y: number;
}
/**
 * A collection of utility functions for working with vectors.
 */
export declare namespace Vector {
    /**
     * The zero vector. It has x and y set to 0.
     */
    const ZERO: Vector;
    /**
     * Compute the absolute value of the vector.
     * @param vector the vector to compute the absolute value of
     * @returns the absolute value of the vector
     */
    function abs(vector: Vector): Vector;
    /**
     * Computes the sum of two vectors.
     * @param vector the vector to add to
     * @param addend the vector to add
     * @returns the sum of the two vectors
     */
    function add(vector: Vector, addend: Vector): Vector;
    /**
     * Check if two vectors are equal.
     * @param left the left vector
     * @param right the right vector
     * @returns true if the vectors are equal, false otherwise
     */
    function equals(left: Vector, right: Vector): boolean;
    /**
     * Check if a vector is valid. A vector is valid if it is not undefined and both x and y are numbers.
     * @param vector the vector to check
     * @returns true if the vector is valid, false otherwise
     */
    function isValid(vector?: Vector): boolean;
    /**
     * Computes the magnitude of a vector defined as the square root of the sum of the squares of the x and y components.
     * @param point the vector to compute the magnitude of
     * @returns the magnitude of the vector
     */
    function magnitude(point: Vector): number;
    /**
     * Maps each component of the vector to a new value given by the callback function.
     * @param vector the vector to map
     * @param callbackfn the function to map the components
     * @returns the mapped vector
     */
    function map(vector: Vector, callbackfn: (value: number, key: keyof Vector) => number): Vector;
    /**
     * Computes the normalized vector of a given vector.
     * The normalized vector has the same direction as the original vector but a magnitude of 1.
     *
     * @param vector the vector to normalize
     * @returns the normalized vector
     */
    function normalize(vector: Vector): Vector;
    /**
     * Check if a vector is the zero vector.
     * @param vector the vector to check
     * @returns true if the vector is the zero vector, false otherwise
     */
    function isZero(vector: Vector): boolean;
    /**
     * Type guard to check if a value is a vector.
     * @param vector the value to check
     * @returns true if the value is a vector, false otherwise
     */
    function is(vector: any): vector is Vector;
    /**
     * Divides each component of the vector by a scalar.
     *
     * @param vector the vector to divide
     * @param scalar the scalar to divide by
     * @returns the divided vector
     */
    function divide(vector: Vector, scalar: number): Vector;
    /**
     * Multiplies each component of the vector by a scalar.
     *
     * @param vector the vector to multiply
     * @param scalar the scalar to multiply by
     * @returns the multiplied vector
     */
    function multiply(vector: Vector, scalar: number): Vector;
    /**
     * Subtracts the subtrahend from the vector.
     *
     * @param vector the vector to subtract from
     * @param subtrahend the vector to subtract
     * @returns the subtracted vector
     */
    function subtract(vector: Vector, subtrahend: Vector): Vector;
    /**
     * Reverse the direction of a vector.
     * @param vector the vector to reverse
     * @returns the reversed vector
     */
    function reverse(vector: Vector): Vector;
    /**
     * Computes the direction of a vector
     * @param vector the vector to compute the direction of
     * @returns the direction of the vector
     */
    function direction(vector: Vector): Direction[];
    /**
     * Computes a vector that is the minimum of all given vectors.
     * @returns the minimum vector
     */
    function min(...vectors: Vector[]): Vector;
    /**
     * Computes a vector that is the maximum of all given vectors.
     * @returns the maximum vector
     */
    function max(...vectors: Vector[]): Vector;
    /**
     * Computes a vector that is the average of all given vectors.
     * @returns the average vector
     */
    function avg(...vectors: Vector[]): Vector;
}
//# sourceMappingURL=geometry-vector.d.ts.map