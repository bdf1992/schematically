/********************************************************************************
 * Copyright (c) 2023-2026 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import * as jsonrpc from 'vscode-jsonrpc';
/**
 * Interface for objects that can or need to be disposed properly.
 */
export interface Disposable extends jsonrpc.Disposable {
    /**
     * Dispose this object.
     */
    dispose(): void;
}
export declare namespace Disposable {
    function is(value: unknown): value is Disposable;
    /**
     * Creates a new empty i.e. no-op {@link Disposable}.
     * @returns the newly created disposable
     */
    function empty(): Disposable;
    /**
     * Creates a new {@link Disposable} that delegates to the given callback.
     * @param cb The callback that should be invoked on dispose
     * @returns the newly created disposable
     */
    function create(cb: () => void): Disposable;
    /**
     * Disposes the given object if it is a {@link Disposable}.
     * @param value The object that should be disposed
     */
    function dispose(value: unknown): void;
}
/**
 * Reusable base class to manage a collection of {@link Disposable}s.
 */
export declare class DisposableCollection implements Disposable {
    protected readonly disposables: Disposable[];
    errorHandler?: (err: unknown) => void;
    constructor(...toDispose: Disposable[]);
    dispose(): void;
    get disposed(): boolean;
    /**
     * Pushes the given disposables to the collection.
     * @param disposables The disposables that should be added
     * @returns A disposable that removes the previously pushed values from the collection when invoked
     */
    push(...disposables: Disposable[]): Disposable;
    push(...disposables: (() => void)[]): Disposable;
    get isDisposed(): boolean;
    /**
     * Removes all disposables in this collection WITHOUT triggering their disposal behavior.
     */
    clear(): void;
}
//# sourceMappingURL=disposable.d.ts.map