/********************************************************************************
 * Copyright (c) 2024-2026 Axon Ivy AG and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
/**
 * Default epsilon for loose numeric equality checks, matching the tolerance
 * used by sprotty's `almostEquals` convention.
 */
export declare const ALMOST_EQUAL_EPSILON = 0.001;
export declare function equalUpTo(one: number, other: number, epsilon?: number): boolean;
//# sourceMappingURL=math-util.d.ts.map