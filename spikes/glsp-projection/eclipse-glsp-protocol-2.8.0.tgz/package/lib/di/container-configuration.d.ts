/********************************************************************************
 * Copyright (c) 2023-2024 EclipseSource and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { Container, ContainerModule } from 'inversify';
import { MaybeArray } from '../utils/array-util';
import { FeatureModule } from './feature-module';
/**
 * Initializes a container with the given {@link ContainerConfiguration}. The container configuration
 * consists of the set of {@link ContainerModule}s that should be loaded in the container.
 * In addition, for more fine-grained control {@link ModuleConfiguration}s can be passed as part fo the container configuration
 * Module loading is distinct,this means each module will only get loaded once even if it is configured multiple times.
  @param containerConfigurations
 *          Custom modules to be loaded in addition to the default modules and/or default modules that should be excluded.
  @returns The initialized container.
 */
export declare function initializeContainer(container: Container, ...containerConfigurations: ContainerConfiguration): Container;
/**
 * Processes the given container configurations and returns the corresponding set of {@link ContainerModule}s.
 * Container configurations are processed in the order they are passed. If a module is configured to be removed
 * it can be added again in a later configuration. This also means in case of `replace` configurations that affect the same feature id
 * the last configuration wins.
 * @param containerConfigurations The container configurations to resolve
 * @throws An error if featureModule ids are not unique in the resolved module array
 * @returns an Array of resolved container modules
 */
export declare function resolveContainerConfiguration(...containerConfigurations: ContainerConfiguration): ContainerModule[];
/**
 * Union type for the set of {@link ContainerModule}s and addition {@link ModuleConfiguration}s
 * used to configure a DI container.
 */
export type ContainerConfiguration = Array<ContainerModule | ModuleConfiguration>;
/**
 * Can be passed to create DI container utility functions to configure additional modules or
 * remove (i.e. not load) default modules.
 */
export interface ModuleConfiguration {
    /** Set of modules that should be loaded into the container. */
    add?: MaybeArray<ContainerModule>;
    /** Set of modules that should be loaded into the container */
    remove?: MaybeArray<ContainerModule>;
    /**
     * Set of feature modules that should be loaded into the container and
     * replace potential already configured modules with the same feature id.
     * When resolving the replacement module will be added at the index of the module it replaces.
     * If there is no module to replace, the replacement module will be added to the end of the list (i.e. behaves like `add`).
     */
    replace?: MaybeArray<FeatureModule>;
}
//# sourceMappingURL=container-configuration.d.ts.map